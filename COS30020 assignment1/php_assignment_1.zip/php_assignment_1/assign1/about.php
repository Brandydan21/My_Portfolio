<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="description" content="Web application development" />
<meta name="keywords" content="PHP" />
<meta name="author" content="Your Name" />
<link rel="stylesheet" type="text/css" href="styles.css">
<title>Job Post Process</title>
</head>
<body>
    <header>
        <article>
            <h1>Job Post Process</h1>
        <article>
    </header>
    <main>
    
    <article>
         <div class="container">
         <!--Print about page-->
        <?php 
            echo "<b><h1>About Page</h1></b><br/>";
            echo "<P> The mercury version installed is: ".phpversion()."</p><br/><hr>";
            echo "<p>I have completed all taks</p><br/><hr>";
            echo '<p>Some special features I have are implemented are:</p>
            <ul>
                <li>Used CSS to create a nice looking page</li>
                <li>Create Containers to store messages</li>
                <li>Create a header and footer that stays in position</li>
                <li>Create custom buttons for page</li>
                <li>Create custom fonts for certain elements on page</li>
                <li>I completed Task 7 - Advanced Search Job Vacancy Page, this allows users to apply filters and stack filters to ensure desired results</li>
                <li>I completed Task 8 - Order and Display Job Vacancy Result Page, this ordered the date from furthest closing date to closest, and also removed out of date listings</li>
            </ul><br><hr>
            <p> I did not post anything on the discussion board, because there was nothing I was too unsure of, however this was helpful</p>
          
            <img src="style/img1.png" alt="My Image">
            <p><a href="index.php">Return to Home Page</a></p>';
            
            
            
    
            
           

        ?>
         

    </div>
    </article>
     </main>
    <footer >
        <p>Brandy's COS30020 Project</p>
    </footer>
</body>
</html>
