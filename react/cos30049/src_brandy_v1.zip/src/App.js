import logo from "./logo.svg";
import "./App.css";
import Grid from "./grid.js";

function App() {
  return (
    <div className="App">
      <Grid></Grid>
    </div>
  );
}

export default App;
